/*
 * Zeta Producer Protected Area
 * http://www.zetaproducer.com
 * 
 * @author  Daniel Friedrich
 * @version 1.0 11.11.2011
 * @copyright (c)2011 Zeta Software GmbH
*/

var _homeUrl = null;
var _sessionId = null;
var _bAnmelden = 'Anmelden';
var _bAbbrechen = 'Abbrechen';

function InitPa( sessionId,
			   	 homeUrl,
			   	 banmelden,
			   	 babbrechen)
{
	_sessionId = sessionId;
	_homeUrl = homeUrl;
	_bAnmelden = banmelden;
	_bAbbrechen = babbrechen;
	
	initDialog();
}

function ShowLoginDialog()
{
	$( "#login-form" ).dialog( "open" );
}

function initDialog(){
			var pagePassword = $( "#password" );
			var	tips = $( "#validateTips" );
			var valid= false;

			function loginError( t ) 
			{
				tips.text( t );
				tips.addClass( "ui-state-highlight" );
				pagePassword.addClass( "ui-state-error" );
				setTimeout(function() 
				{
					tips.removeClass( "ui-state-highlight", 1500 );
				}, 500 );
			}			
			$( "#login-form" ).dialog({
				autoOpen: false,
				height: 270,
				minHeight: 270,
				width: 290,
				modal: true,
				resizable: false,
				hide: "fade",
				show: "fade",
				buttons: [
					{
						text: _bAnmelden,
						click: function() {
							pagePassword.removeClass( "ui-state-error" );
					
							$.get( window.location.href,
									{
										action: "login",
										password: pagePassword.val(),
										PHPSESSID: _sessionId
									},
									function(data)
									{
										if ( data == "ok" ) 
										{
											$( "#login-input-area" ).fadeOut();
											setTimeout(function() 
											{
												tips.text( "..." );
											}, 250 )
										
											setTimeout(function() 
											{
												$( "#login-form" ).dialog( "close" );
											}, 500 )
										
											valid = true;
										}
										else
										{
											loginError( data );
										}
									}
								);
						}
					},
					{
						text: _bAbbrechen,
						click: function() {
							$( this ).dialog( "close" );
						}
					}
				],
				close: function() {
					if ( valid )
					{
						location.reload(true);
					}
					else
					{
						window.location = _homeUrl ;
						//$( "body" ).load( _homeUrl ).fadeTo();
					}
				},
				open:function () {
					$(this).next(".ui-dialog-buttonpane")
						.find(".ui-button:first") // the first button
						.addClass("anmelden");
				}
			});

			$('#login-form').on('keyup', function(e){   if (e.keyCode == 13) {     $('button.anmelden').click();   } }); 
				
}