<?php
/**
 * Class PALogin
 *
 * Manages login taks
 * 
 * @author  Daniel Friedrich
 * @version 1.0 09.11.2011
 * @copyright (c)2011 zeta Software GmbH
 */

Class PALogin
{   
	private $masterController = null;   
	
	/**  
	 * Contructor
	 *  
	 * @param Array $masterController.  
	 */  
	public function __construct(
		$masterController)
	{   
		$this->masterController = $masterController;
	}

	/**
	* Checks the login data of a user.
	* -> Direct output for ajax call.
	*
	* @param Array Request
	* @param PAView
	*/
	public function LoginUser(
		$request,
		$view)
	{
		$pagePassword = $this->getPagePassword();
		
		if($request["password"] == $pagePassword)
		{
			$_SESSION[$this->masterController->getArea() . '_isLoggedInPA'] = true;
			echo "ok"; 
		}
		else
		{
			echo $GLOBALS["pa_zugang_abgelehnt"];
		}
	}
	
	public function LogoutUser(
		$request,
		$view)
	{
		unset( $_SESSION[$this->masterController->getArea() . '_isLoggedInPA'] );
	}
	
	public function getIsLoggedIn()
	{
		if ( isset( $_SESSION[$this->masterController->getArea() . '_isLoggedInPA'] ))
		{
			return true;
		}
		return false;
	}
	
	/**
	* Gets the set page password out of the session.
	* If not set tries to get out of the producer generated page that includes the script. 
	*/
	public function getPagePassword()
	{		
		if ( isset( $_SESSION[$this->masterController->getArea() . "_pagePassword"] ) )
		{
			return $_SESSION[$this->masterController->getArea() . "_pagePassword"];
		}
		if ( isset( $GLOBALS["displayPagePassword"]) )
		{
			$_SESSION[$this->masterController->getArea() . "_pagePassword"] = $GLOBALS["displayPagePassword"];
			return $GLOBALS["displayPagePassword"];
		}
	}
}
?>