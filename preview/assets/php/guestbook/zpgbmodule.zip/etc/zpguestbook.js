/*
 * ZP Guestbook 
 * $Id$
*/

var _dataDomain = null;
var _sessionId = null;
var _currentEntryId = null;

function InitGuestbook( dataDomain,  
				  sessionId,
				  showLoginDialog)
{
	_dataDomain = dataDomain;
	_sessionId = sessionId;
	
	if ( showLoginDialog )
	{
		OpenLoginDialog();		
	}
}
					
function OpenLoginDialog()
{
	$z( "#login-form" ).dialog( "open" );
}

$z( function() 
{
	var pagePassword = $z( "#password" );
	var	tips = $z( "#validateTips" );

	function loginError( t ) 
	{
		tips.text( t );
		tips.addClass( "ui-state-highlight" );
		pagePassword.addClass( "ui-state-error" );
		setTimeout(function() 
		{
			tips.removeClass( "ui-state-highlight", 1500 );
		}, 500 );
	}
	
	$z( "#login-form" ).dialog({
		zIndex: 7000,
		autoOpen: false,
		height: 240,
		width: 280,
		modal: true,
		hide: "fade",
		show: "fade",
		buttons: {
			"Anmelden": function() {
				pagePassword.removeClass( "ui-state-error" );
			
				$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
						{
							view: "editEntries",
							action: "login",
							password: pagePassword.val(),
							dataDomain: _dataDomain,
							PHPSESSID: _sessionId
						},
						function(data)
						{
							if ( data == "ok" ) 
							{
								$z( "#login-input-area" ).fadeOut();
								setTimeout(function() 
								{
									tips.text( "Administrationsumgebung wird geladen..." );
								}, 500 )
										
								$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
									{
										view: "editEntries",
										dataDomain: _dataDomain,
										async: "true",
										PHPSESSID: _sessionId
									},
									function(data)
									{
										setTimeout(function() 
										{
											$z( "#guestbook_content" ).html( data ).fadeTo();
											$z( "#login-form" ).dialog( "close" );
										}, 2000 )
									}
								);													
							}
							else
							{
								loginError( data );
							}
						}
					);
			},
			"Abbrechen": function() {
				$z( this ).dialog( "close" );
			}
		},
		close: function() {
			tips.text( "Um in den Administrationsmodus zu wechseln, melden Sie sich bitte an." );
			$z( "#login-input-area" ).fadeIn();
			pagePassword.val( "" ).removeClass( "ui-state-error" );
		}
	});

	$z('#login-form').on('keyup', function(e){   if (e.keyCode == 13) {     $z(':button:contains("Anmelden")').click();   } }); 
		
});

function reportEditEntryError( t ) 
{
	$z( "#validateTipsEdit" ).text( t );
	$z( "#validateTipsEdit" ).addClass( "ui-state-highlight" );
	$z( "#validateTipsEdit" ).show();
	
	setTimeout(function() 
	{
		$z( "#validateTipsEdit" ).removeClass( "ui-state-highlight", 1500 );
	}, 500 );
	setTimeout(function() 
	{
		$z( "#validateTipsEdit" ).fadeOut();
	}, 5000 );
}

function retrieveDataAsync( entryId, callback )
{				
	$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
			{
				view: "dataRequest",
				action: "dataRequest",
				entryId: entryId,
				dataDomain: _dataDomain,
				async: "true",
				PHPSESSID: _sessionId
			},
			function(data)
			{	
				callback( data );
			}
	);
} 

function retrieveDataSync( entryId )
{
	 var result = null;      
	 var scriptUrl = "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php";      
	 $z.ajax(
	 {
		 url: scriptUrl,
		 type: 'get',
		 dataType: 'html',
		 async: false,
		 data:
		 {
			view: "dataRequest",
			action: "dataRequest",
			entryId: entryId,
			dataDomain: _dataDomain,
			async: "true",
			PHPSESSID: _sessionId
		 },
		 success: function(data) 
		 {
			 result = data;
		 }
	 });
	 
	 return result;
}

function setEntryData( entryData )
{
	var arrData = entryData.split(";;;");
	var name = $z( "#zpgbname" );
	var email = $z( "#zpgbemail" );
	var homepage = $z( "#zpgbhomepage" );
	var text = $z( "#zpgbtext" );
	var ip = $z( "#zpgbip" );
	
	if( arrData.length <= 1  )
	{
		alert("Fehler bei der Datenübertragung.\n" + entryData);
		return;
	}

	name.val( arrData[0] );
	email.val( arrData[1] );
	homepage.val( arrData[2] );
	text.val( arrData[3] );
	ip.html( arrData[4] );
}

function editEntry(entryId, startAt)
{
	var name = "";
	var email = "";
	var homepage = "";
	var text = "";
	
	if( entryId != 0 )
	{
		retrieveDataAsync( entryId, setEntryData  );	
	}
	
	_currentEntryId = entryId;

	showEditEntryDialog( entryId, name, email, homepage ,text, startAt);
}

function storeEntry( entryId, 
					   sName,
					   sEmail,
					   sHomepage,
					   sText )
{
	var result = null;      
	var scriptUrl = "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php";
	
	 $z.ajax(
	 {
		 url: scriptUrl,
		 type: 'post',
		 dataType: 'html',
		 async: false,
		 data:
		 {
			view: "dataRequest",
			action: ( entryId ) > 0 ? "storeEntry" : "addNewEntry",
			async: "true",
			entryId: entryId,
			Name: sName,
			Email: sEmail,
			Homepage: sHomepage,
			Text: sText,
			dataDomain: _dataDomain,
			PHPSESSID: _sessionId
		 },
		 success: function(data) 
		 {
			 result = data;
		 }
	 });
	 
	 return result;
}

function updateContentAsync( request )
{
	$z( "#guestbook_content" ).load( "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php?async=true&dataDomain="  + _dataDomain + "&PHPSESSID=" + _sessionId + "&" + request );
}

function updateEntriesAsync( request )
{
	$z( "#entries" ).load( "<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php?view=entries&async=true&dataDomain=" + _dataDomain + "&PHPSESSID=" + _sessionId + "&" + request);
}

function showreCaptchaDialog(){
	$z( "#dialog-recaptcha" ).dialog({
		dialogClass: "xhiddendialog",
		zIndex: 7000,
		autoOpen: true,
		resizable: false,
		height: 280,
		width: 400,
		modal: true,
		hide: "fade",
		show: "fade",
		buttons: {
			"Abbrechen": function() {
				$z( this ).dialog( "close" );
			}
		},
		open: function(){
			// verify reCaptcha
			grecaptcha.reset();
			grecaptcha.execute();
		}
	})
}
function showEditEntryDialog( 
		entryId,  
		sName, 
		sEmail, 
		sHomepage, 
		sText,
		startAt)
{		
	var name = $z( "#zpgbname" );
	var email = $z( "#zpgbemail" );
	var homepage = $z( "#zpgbhomepage" );
	var text = $z( "#zpgbtext" );
	var	tips = $z( "#validateTipsEdit" );
	
	name.val( sName );	
	text.html( sText );
	if ( entryId == 0 ){
		var dialogTitle = "Neuer Eintrag";
	}
	else{
		var dialogTitle = "Eintrag bearbeiten"
	}
	
	$z( "#dialog-edit-entry" ).dialog({
		title: dialogTitle,
		zIndex: 7000,
		autoOpen: true,
		resizable: false,
		height: 555,
		width: 550,
		modal: true,
		hide: "fade",
		show: "fade",
		buttons: {
			"OK": function() {
				var errorState = false;
				text.removeClass( "ui-state-error" );
				name.removeClass( "ui-state-error" );

				if( text.val().length == 0){
					text.addClass( "ui-state-error" );
					reportEditEntryError ( "Bitte geben Sie einen Text ein." );
					errorState = true;
					text.focus();
				}
				
				if( name.val().length == 0 || name.val() == "Geben Sie Ihren Namen ein"){
					name.addClass( "ui-state-error" );
					reportEditEntryError ( "Geben Sie Ihren Namen ein." );
					errorState = true;
					name.focus();
				}
				
				if( errorState ){
					return;
				}

				tips.text( "Eintrag wird gespeichert..." );

				data = storeEntry( _currentEntryId, 
									 name.val(),
									 email.val(),
									 homepage.val(),
									 text.val() );

				if ( is_int( data ) && data > 0){			
					$z.get("<?php echo $this->_['Configuration']['siteUrl'];?>/assets/php/guestbook/gb.main.php",
						{
							view: "entries",
							startAt: startAt,
							dataDomain: _dataDomain,
							async: "true",
							PHPSESSID: _sessionId
						},
						function(data)
						{		
							$z( "#entries" ).html( data ).fadeTo();
						
							setTimeout( function(){
								$z( "#dialog-edit-entry" ).dialog( "close" );
								tips.text( "" );
								
								$z( "#dialog-confirm-entry" ).dialog({
									zIndex: 7000,
									autoOpen: true,
									resizable: false,
									height: 280,
									width: 550,
									modal: true,
									hide: "fade",
									show: "fade",
									open: function(event, ui){
										setTimeout("$z('#dialog-confirm-entry').dialog('close')", 4000);
									}
								});
								
								
							}, 500 );	
						}
					);													
				}
				else{
					reportEditEntryError( data );
				}
			},
			"Abbrechen": function() {
				$z( this ).dialog( "close" );
			}
		},
		open: function()
		{	
			tips.hide();
			window.onbeforeunload = function(){ return 'Wenn Sie diese Seite verlassen, gehen die aktuellen Änderungen verloren.\nSind Sie sicher?'; }
			name.css('color', '#000000');
								
			name.focus( function() 
			{				
		        if(this.value == this.defaultValue) 
			    {
		            this.value = "";
		            $z(this).css('color', '#000000');

			    } 
		    }); 
			
			name.blur( function() 
			{
		        if( this.value == "")
		        {
		            this.value = this.defaultValue;
		            $z(this).css('color', '#666');
		        }
		    }); 
		    
		    $(this).next().prepend('<p style="float: left; margin: .5em 0 .5em .4em;">Noch <span id="charcount" >5000</span> Zeichen erlaubt.</p>');
		},
		close: function() 
		{
			window.onbeforeunload = null;
			name.val( "" );
			text.val( "");
			homepage.val( "" );
			email.val ( "" );
		}
	});
}

function deleteEntry( id, name, start )
{
	document.getElementById('dialog-confirm-deletion-text').innerHTML = "Wollen Sie den Eintrag von \"" + name + "\" wirklich löschen?";
	
	if ($("#dialog-confirm-deletion").hasClass('ui-dialog-content')) {
		$z( "#dialog-confirm-deletion" ).dialog( "destroy" );
	}
	
	$z(function() {
		$z( "#dialog-confirm-deletion" ).dialog({
			zIndex: 7000,
			resizable: false,
			height:180,
			width:300,
			modal: true,
			hide: "fade",
			show: "fade",
			buttons: {
				"OK": function() {
					$z( this ).dialog( "close" );
					
					updateEntriesAsync("action=deleteEntry&entryId=" + id + "&startAt=" + start);
				},
				"Abbrechen": function() {
					$z( this ).dialog( "close" );
				}
			}
		});
	});
}

function is_int(value){ 
	  if((parseFloat(value) == parseInt(value)) && !isNaN(value)){
	       return true;
	   } else { 
	      return false;
	   } 
	}