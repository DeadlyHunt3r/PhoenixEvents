<?php
	function scanDirEx( $path='.', $mask='*' )
		{  
			$sdir = array();
		    $entries = scandir($path);
		     
		    foreach ($entries as $i=>$entry) { 
		        if ($entry!='.' && $entry!='..' && fnmatch($mask, $entry) ) { 
		            $sdir[] = $entry; 
		        } 
		    } 
		    return ($sdir); 
		}
		
	function getRelativePath( $path, $compareTo ) {
        // clean arguments by removing trailing and prefixing slashes
        if ( substr( $path, -1 ) == '/' ) {
            $path = substr( $path, 0, -1 );
        }
        if ( substr( $path, 0, 1 ) == '/' ) {
            $path = substr( $path, 1 );
        }

        if ( substr( $compareTo, -1 ) == '/' ) {
            $compareTo = substr( $compareTo, 0, -1 );
        }
        if ( substr( $compareTo, 0, 1 ) == '/' ) {
            $compareTo = substr( $compareTo, 1 );
        }

        // simple case: $compareTo is in $path
        if ( strpos( $path, $compareTo ) === 0 ) {
            $offset = strlen( $compareTo ) + 1;
            return substr( $path, $offset );
        }

        $relative  = array(  );
        $pathParts = explode( '/', $path );
        $compareToParts = explode( '/', $compareTo );

        foreach( $compareToParts as $index => $part ) {
            if ( isset( $pathParts[$index] ) && $pathParts[$index] == $part ) {
                continue;
            }

            $relative[] = '..';
        }

        foreach( $pathParts as $index => $part ) {
            if ( isset( $compareToParts[$index] ) && $compareToParts[$index] == $part ) {
                continue;
            }

            $relative[] = $part;
        }

        return implode( '/', $relative );
    }
    
	function array_msort($array, $cols)
	{
	    $colarr = array();
	    foreach ($cols as $col => $order) 
	    {
	        $colarr[$col] = array();
	        foreach ($array as $k => $row) 
	        { 
	            $colarr[$col]['_'.$k] = strtolower($row[$col]); 
	        }
	    }
	    $params = array();
	    foreach ($cols as $col => $order) 
	    {
	    
	        $params[] =&$colarr[$col];
	        $order=(array)$order;
	        foreach($order as $order_element)
	        {
	            //pass by reference, as required by php 5.3
	            $params[]=&$order_element;
	        }
	    }
	    call_user_func_array('array_multisort', $params);
	    $ret = array();
	    $keys = array();
	    $first = true;
	    foreach ($colarr as $col => $arr) 
	    {
	        foreach ($arr as $k => $v) 
	        {
	            if ($first) 
	            { 
	                $keys[$k] = substr($k,1); 
	            }
	            $k = $keys[$k];
	            
	            if (!isset($ret[$k]))
	            {
	                $ret[$k] = $array[$k];
	            }
	            
	            $ret[$k][$col] = $array[$k][$col];
	        }
	        $first = false;
	    }
	    return $ret;
	}
    
	
	function array_orderby()
	{
	    $args = func_get_args();
	    $data = array_shift($args);
	    foreach ($args as $n => $field) {
	        if (is_string($field)) {
	            $tmp = array();
	            foreach ($data as $key => $row)
	                $tmp[$key] = $row[$field];
	            $args[$n] = $tmp;
	            }
	    }
	    $args[] = &$data;
	    call_user_func_array('array_multisort', $args);
	    return array_pop($args);
	}	
	
	function getExtension($str) 
	{

         $i = strrpos($str,".");
         if (!$i) { return ""; }          $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 	}
 	
 	function mb_mime_header($string, $encoding=null, $linefeed="\r\n") 
	{
		if(!$encoding) $encoding = mb_internal_encoding();
	 	$encoded = '';
	 
	 	while($length = mb_strlen($string)) 
	  	{
	    	$encoded .= "=?$encoding?B?"
	              . base64_encode(mb_substr($string,0,24,$encoding))
	              . "?=$linefeed";
	 
	    	$string = mb_substr($string,24,$length,$encoding);
	   	}
	   	return $encoded;
	}
	
	function encode_mailto($mail, $label, $subject = "", $body = "") {
    $chars = preg_split("//", $mail, -1, PREG_SPLIT_NO_EMPTY);
    $new_mail = "<a href=\"mailto:";
    foreach ($chars as $val) {
        $new_mail .= "&#".ord($val).";";
    }
    $new_mail .= ($subject != "" && $body != "") ? "?subject=".$subject."&body=".$body : "";
    $new_mail .= "\">".$label."</a>";
    return $new_mail;
	}
 	
?>