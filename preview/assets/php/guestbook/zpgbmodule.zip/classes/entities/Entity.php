<?php
/**
 * Class Entity
 *
 * Base class for entities. 
 * 
 * $Id$
 * @copyright (c) zeta Software GmbH
 */
abstract class Entity
{
	protected $model;
	protected $id = 0;
	protected $dateCreated = 0;
	
	public function __construct( $model )
	{
		$this->model = $model;
	}
	
	public function Load( $row )
	{
		$this->id = $row['ID'];
		$this->dateCreated = $row['DateCreated'];
	}
	
	public function StoreRow( &$row )
	{
		$row['ID'] = $this->id;
		$row['DateCreated'] = $this->dateCreated;
	}
	
	abstract public function Store();
	abstract public function Delete();
	
	/**
	 * @return the $model
	 */
	public function getModel() {
		return $this->model;
	}
	
	/**
	 * @return the $id
	 */
	public function getId() {
		return $this->id;
	}

	/**
	 * @param field_type $id
	 */
	public function setId($id) {
		$this->id = $id;
	}
	
	/**
	 * @return the $dateCreated
	 */
	public function getDateCreated() {
		return $this->dateCreated;
	}

	/**
	 * @param field_type $dateCreated
	 */
	public function setDateCreated($date) {
		$this->dateCreated = $date;
	}


}
?>