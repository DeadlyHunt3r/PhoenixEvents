<?php
$entries = $this->_['entries'];
$isEditMode = $this->_['isEditMode'];
$isLoggedIn = $this->_['isLoggedIn'];
$dataDomain = $this->_['dataDomain'];
$approvalRequired = $this->_['approvalRequired'];
$siteUrl =  $this->_['Configuration']['siteUrl'];
$showEntriesCount = $this->_['showEntriesCount'];
$startAt = $this->_['startAt'];
$view = $this->_['view'];
?>
<?php 
	if ( $view == "editEntries" ) 
	{
?>
	<div id="dialog-confirm-deletion" title="Eintrag löschen" style="display:none;">
		<p>
			<span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 10px 0;"></span>
			<span id="dialog-confirm-deletion-text"></span>
		</p>
	</div>
<?php
	}
?>
	<?php if ( $_SESSION["siteKey"] !== "" ){ ?>
	<div id="dialog-recaptcha" title="Sicherheitsprüfung" style="display:none;">
		
		<h3>Sicherheitsprüfung</h3>
		<p>
		Augenblick, wir machen eine kurze Prüfung um automatisierte Veröffentlichungen zu vermeiden.
		</p>
		<div id='recaptcha' class="g-recaptcha" style="margin-top: 1em;" 
			  data-sitekey='<?=$_SESSION["siteKey"]?>'
			  data-callback="onSubmit"
			  data-size="invisible">
		</div>
		<script src='//www.google.com/recaptcha/api.js' async defer></script>
		<script>
		   function onSubmit(token) {
				$z( "#dialog-recaptcha" ).dialog("close");
				editEntry(0);
		   }
		</script>
	</div>
	<?php } ?>
	
	<div id="dialog-edit-entry" title="Eintrag bearbeiten" style="display:none;"<?php if ($approvalRequired && !$isLoggedIn){ ?> data-approval="true"<?php } else { ?> data-approval="false"<?php } ?>>
	<?php
	if ( $approvalRequired && !$isLoggedIn)
	{
	?>
	<span><strong>Hinweis: Ihr Eintrag wird vor der Veröffentlichung von uns geprüft.</strong></span>
	<?php
	}
	?>
	<p id="validateTipsEdit"></p>
	<fieldset class="zp-form zp14 autohidelabels">
		<div class="resizablefield c12 fieldinnewline ">
		<label class="field" for="zpgbname">Name:</label>
		<input type="text" name="Name" placeholder="Geben Sie Ihren Namen ein" id="zpgbname" class="typetext text ui-widget-content ui-corner-all" style="width:98%; display:block; font-weight: bold; font-size: 1.1em" />
		</div>
		<div class="resizablefield c12 fieldinnewline ">
		<label class="field" for="zpgbemail">E-Mail:</label>
		<input type="text" name="Email" id="zpgbemail" placeholder="Geben Sie Ihre E-Mail-Adresse ein (optional)" class="typetext text ui-widget-content ui-corner-all" style="width:98%; display:block; font-size: 1.1em" />
		</div>
		<div class="resizablefield c12 fieldinnewline ">
		<label class="field" for="zpgbhomepage">Website:</label>
		<input type="text" name="Homepage" id="zpgbhomepage" placeholder="Geben Sie Ihre Website-Adresse ein (optional)" class="typetext text ui-widget-content ui-corner-all" style="width:98%; display:block; font-size: 1.1em" />
		</div>
		<div class="resizablefield c12 fieldinnewline ">
		<label class="field" for="zpgbhomepage">Ihr Kommentar:</label>
		<textarea name="Text" id="zpgbtext" placeholder="Geben Sie Ihren Kommentar ein"class="text ui-widget-content ui-corner-all" style="width: 98%; height:180px; display:block; font-size: 1.1em" onkeyup="countChar(this, '#charcount');"></textarea>
		</div>
		<?php 
		if ( $isLoggedIn ) 
		{ 
			?>
			<span>IP-Adresse:&nbsp;</span><span id="zpgbip"></span>
			<?php 	
		}
		?>
	</fieldset>
	</div>

	<div id="dialog-confirm-entry" style="display:none;">
		<?php
		if ( $approvalRequired && !$isLoggedIn){
		?>
		<h2>Vielen Dank!</h2> <strong>Ihr Eintrag wird vor der Veröffentlichung von uns geprüft und dann entsprechend Freigeschaltet.</strong>
		<?php
		} else {
		?>
		<h2>Vielen Dank!</h2> <strong>Ihr Eintrag wurde erfolgreich übermittelt.</strong>
		<?php
		}
		?>
	</div>
	
	<div style="text-align:left; margin-bottom: 15px;">
	<?php if ( $_SESSION["siteKey"] !== "" ){ ?>
	<a id="btnInsertArticle" onclick="javascript:showreCaptchaDialog(); return false;" href="#">Neuen Eintrag hinzufügen</a>
	<?php } else { ?>
	<a id="btnInsertArticle" onclick="javascript:editEntry(0); return false;" href="#">Neuen Eintrag hinzufügen</a>
	<?php } ?>
	</div>

	<div id="entries">
<?php 
		$viewArticles = new View();
		$viewArticles->SetTemplate('entries');
				
		$viewArticles->Assign('entries', $entries);
		$viewArticles->Assign('isEditMode', $isEditMode);
		$viewArticles->Assign('isLoggedIn', $isLoggedIn);
		$viewArticles->Assign('showEntriesCount', $showEntriesCount);
		$viewArticles->Assign('startAt', $startAt);

		echo $viewArticles->LoadTemplate();
?>
</div>

<p></p>
<?php	
if ( $isLoggedIn )
{
?>
	<input type="button" id="btnLogout" onClick="javascript:window.location = '?action=logout'; return false;" value="Abmelden"/>
	<script>
		$z( "#btnLogout" ).button();
	</script>
<?php
}
?>