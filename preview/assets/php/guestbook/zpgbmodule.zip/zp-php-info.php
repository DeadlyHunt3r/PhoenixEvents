<?php 
phpinfo(); 
phpversion(); 
?> 